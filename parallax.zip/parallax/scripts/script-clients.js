// Lista de comentários
const feedbacks = [
    { user: "João Silva", comment: "Ótimo produto! Entrega rápida e qualidade excelente." },
    { user: "Maria Oliveira", comment: "Adorei! Superou minhas expectativas." },
    { user: "Carlos Souza", comment: "Recomendo a todos! Vale cada centavo." },
    { user: "Ana Costa", comment: "Excelente atendimento e produtos de alta qualidade." },
    { user: "Pedro Rocha", comment: "Muito satisfeito com a compra." },
    { user: "Fernanda Lima", comment: "Produto chegou antes do prazo. Recomendo!" },
    { user: "Ricardo Alves", comment: "Qualidade impecável e preço justo." },
    { user: "Juliana Santos", comment: "Adorei a variedade de produtos oferecidos." },
    { user: "Lucas Pereira", comment: "Ótimo custo-benefício." },
    { user: "Camila Ribeiro", comment: "Atendimento rápido e eficiente." },
    { user: "Marcos Vieira", comment: "Produtos duráveis e de alta qualidade." },
    { user: "Patrícia Nunes", comment: "Comprei várias vezes e sempre fui bem atendida." },
    { user: "Gustavo Henrique", comment: "Entrega rápida e produtos bem embalados." },
    { user: "Isabela Freitas", comment: "Recomendo a loja para todos os meus amigos." },
    { user: "Roberto Campos", comment: "Preço justo e produtos de qualidade." },
    { user: "Sandra Gomes", comment: "Adorei a facilidade de compra e entrega." },
    { user: "Felipe Mendes", comment: "Produtos exatamente como na descrição." },
    { user: "Larissa Castro", comment: "Atendimento excelente e produtos de primeira." },
    { user: "Bruno Fernandes", comment: "Comprei e não me arrependi. Recomendo!" },
    { user: "Carla Dias", comment: "Loja confiável e produtos de qualidade." }
];

// Variáveis de controle
let currentPage = 0;
const feedbacksPerPage = 3;

// Elementos do DOM
const feedbackList = document.getElementById("feedback-list");
const prevButton = document.getElementById("prev-button");
const nextButton = document.getElementById("next-button");

// Função para carregar os comentários
function loadFeedbacks(page) {
    feedbackList.innerHTML = ""; // Limpa a lista
    const start = page * feedbacksPerPage;
    const end = start + feedbacksPerPage;
    const paginatedFeedbacks = feedbacks.slice(start, end);

    paginatedFeedbacks.forEach(feedback => {
        const feedbackItem = document.createElement("div");
        feedbackItem.classList.add("feedback");
        feedbackItem.innerHTML = `
            <div class="user">${feedback.user}</div>
            <div class="comment">${feedback.comment}</div>
        `;
        feedbackList.appendChild(feedbackItem);
    });

    // Atualiza o estado dos botões de paginação
    prevButton.disabled = page === 0;
    nextButton.disabled = end >= feedbacks.length;
}

// Eventos de paginação
prevButton.addEventListener("click", () => {
    if (currentPage > 0) {
        currentPage--;
        loadFeedbacks(currentPage);
    }
});

nextButton.addEventListener("click", () => {
    if ((currentPage + 1) * feedbacksPerPage < feedbacks.length) {
        currentPage++;
        loadFeedbacks(currentPage);
    }
});

// Carrega os primeiros comentários ao iniciar
loadFeedbacks(currentPage);